// import React, { useContext } from "react";
// import useInputs from "./hooks/useInputs";
// import { tagDispatch } from "./App";

// const CreateTags = () => {
//   const [onChange, reset] = useInputs({});

//   const dispatch = useContext(tagDispatch);

//   const onCreate = () => {
//     dispatch({
//       type: "CREATE_USER",
//       user: {
//         id: nextId.current,
//         username,
//         email,
//       },
//     });
//     console.log(dispatch);
//     reset();
//   };
// };

// export default React.memo(CreateTags);
