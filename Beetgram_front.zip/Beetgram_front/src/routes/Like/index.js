import LikeContainer from "./LikeContainer";

export default LikeContainer;
