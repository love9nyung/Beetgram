import React from "react";
import {
  HashRouter as Router,
  Route,
  Switch,
  useLocation,
} from "react-router-dom";
import Header from "./Header";

import Public from "../routes/Public";
import Home from "../routes/Home";
// import Login from "../routes/Login";

// 오로지 라우터만 관리하는 컴포넌트가 될 것이다.
const Header_ = () => {
  const pathname = useLocation().pathname;
  if (pathname.includes("datail")) {
    return null;
  } else {
    return <Header />;
  }
};
export default () => (
  <Router>
    <>
      <Header />
      {/* 기본적으로 Switch가 없이 라우터를 배치하면 모든 라우터를 탄다.
        Switch를 활용하면 오로지 하나의 라우터만 타게 된다.
      */}
      <Switch>
        <Route path="/home" component={Home} />
        {/* <Route path="/login" exact component={Login} /> */}
        <Route path="/public" component={Public} />
        {/* <Route path="/show/:id" component={Detail} /> */}
      </Switch>
    </>
  </Router>
);
